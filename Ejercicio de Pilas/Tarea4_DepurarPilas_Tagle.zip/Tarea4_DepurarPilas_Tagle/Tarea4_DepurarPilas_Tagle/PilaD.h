#pragma once
#include <iostream>
#define MAX 10
#include<ctime>; 
using namespace std; 
class PilaD
{
public: 
	PilaD();
	void Mostrar();
	void Init(); 
	int Extraer(); 
	void ConsultarE();
	bool Insertar(int); 
	void Depurar(); 

private: 
	int* pila, * pilad; 
	int tope, toped, min, max, extra; 
};

