#include "PilaD.h"

PilaD::PilaD()
{
	min = 0; 
	tope = min - 1; 
	toped = min - 1; 
	max = MAX; 
	pila = new int[MAX]; 
	pilad = new int[MAX]; 
	for (int i = 0; i < MAX; i++)
	{
		pila[i] = 0;
		pilad[i] = 0;
	}
}
void PilaD::Init()
{
	int num; 
	srand(time(0)); 
	for (int i = 0; i <= MAX; i++)
	{
		num = 1 + rand() % (101 - 1);
		pila[i] = num;
		tope++; 
	}
}
int PilaD::Extraer()
{
	cout << "Seleccione una pila: " << endl; 
	int sel=0; 
	do {
		cout << "1.Original"<<endl;
		cout << "2.Depurada"<<endl;
		cin >> sel;
	} while (sel != 1 && sel != 2); 
	if (tope < min)
	{
		return -1;
	}
	if (sel == 1)
	{
		extra = pila[tope];
		pila[tope] = 0;
		tope--;
	}
	else
	{
		extra = pilad[toped];
		pilad[toped] = 0;
		toped--;
	}

	return extra;

}
bool PilaD::Insertar(int insert)
{
	if (tope >= max)
		return false; 
	tope++;
	pila[tope] = insert;
	return true; 
}
void PilaD::Mostrar()
{
	int sel = 0;
	do {
		cout << "1.Pila Original" << endl;
		cout << "2.Pila Depurada" << endl;

		cout << "Seleccione la pila a mostrar:  " << endl;
		cin >> sel;
	} while (sel > 2 || sel < 1);
	if (sel == 1)
	{
		cout << "\nPILA: " << endl;
		for (int j = tope; j >= 0; j--)
		{
			cout << "\t" << pila[j];
			if (j == min)cout << "\t<= M�nimo";
			if (j == tope)cout << "\t<= Tope";
			if (j == max)cout << "\t<= M�ximo";
			cout << endl;

		}
		cout << endl;
	}
	if (sel == 2)
	{
		cout << "\nPILA DEPURADA: " << endl;
		for (int i = toped; i >= 0; i--)
		{
			cout << "\t" << pilad[i];
			if (i == min)cout << "\t<= M�nimo";
			if (i == toped)cout << "\t<= Tope";
			if (i == max)cout << "\t<= M�ximo";
			cout << endl;

		}
		cout << endl;
	}
}
	void PilaD::ConsultarE()
	{
		int sel = 0;
		
		if (tope < min)
		{
			cout << "Pila vac�a" << endl;
		}

		
		if (tope >= min)
		{
			cout << "ULTIMO ENTERO REGISTRADO EN LA PILA : " << endl;
			cout << *(pila + tope) << endl;
			cout << "ULTIMO ENTERO REGISTRADO EN LA PILA DEPURADA : " << endl;
			cout << *(pilad + toped) << endl;
		}

	}
	void PilaD::Depurar()
{
		int minimo = 0; 
		cout << "Ingresa el minimo para la depuracion: " << endl; 
		cin >> minimo; 
		cout << "Depurando pila........." << endl; 
		for (int i = 0; i <= tope; i++)
		{
			if (pila[i] > minimo)
			{
				if(toped>=max)
				{
					cout << "LA PILA DEPURADA YA SE ENCUENTRA LLENA: " << endl; 
					break; 
				}
				pilad[toped] = pila[i];
				toped++; 
			}
		}
		cout << "Pila depurada lista: " << endl; 
}
	



