#include "PilaD.h"

void menu()
{
	cout << "1.AGREGAR ENTERO A PILA : " << endl;
	cout << "2.EXTRAER/ELIMINAR NUMERO DE LA PILA : " << endl;
	cout << "3.CONSULTAR PILA: " << endl;
	cout << "4.MOSTRAR PILAS: " << endl;
	cout << "5.DEPURAR PILA: " << endl; 
	cout << "6.SALIR" << endl;

}
int main()
{
	PilaD newP; 
	int sel = 0;
	int newnum, res; 
	newP.Init(); 
	cout << "TAREA 4.PILA DEPURADA" << endl; 
	do {
		menu(); 
		cout << "Selecciona una opcion: " << endl; 
		cin >> sel; 
		switch (sel)
		{
		case 1:
			cout << "1. AGREGAR ENTERO A PILA" << endl;
			cout << "INGRESA UN ENTERO: " << endl;
			cin >> newnum;
			res =newP.Insertar(newnum); 
			cout << res; 
			
			break;
		case 2:
			cout << "2.EXTRAER/ELIMINAR ENTERO" << endl;
			res = newP.Extraer(); 
			cout << res; 
			break;
		case 3:
			cout << "3.CONSULTAR  PILAS" << endl;
			newP.ConsultarE();
			break;
		case 4:
			cout << "MOSTRAR PILA" << endl;
			newP.Mostrar();
			break;
		case 5:
			newP.Depurar(); 
			break; 
		case 6: 
			cout << "Hasta Luego" << endl; 
			break; 
		default:
			cout << "Seleccione una opcion valida: " << endl;
	
	}
	} while (sel != 6); 
}