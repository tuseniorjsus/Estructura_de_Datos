#include "PilaS.h"

void menu()
{
	cout << "---------LG_electronics---------------" << endl;
	cout << "1.AGREGAR NUMERO DE PANTALLA : "<<endl;
	cout << "2.EXTRAER/ELIMINAR NUMERO DE PANTALLA : " << endl; 
	cout << "CONSULTAR �LTIMA PANTALLA REGISTRADA: " << endl; 
	cout << "4.MOSTRAR LISTA DE PANTALLAS: " << endl; 
	cout << "5.SALIR" << endl; 
}
int main()
{

	int selec = 0; 
	PilaS LG; 
	string newPantalla, response; 

	do {
		menu(); 
		cout << "Selecciona una opci�n: " << endl; 
		cin >> selec; 
		cout << "-----------------------------------------" << endl; 
		switch (selec)
		{
		case 1: 
			cout << "1. AGREGAR PANTALLA" << endl; 
			cout << "Ingrese el numero de serie de la pantalla: " << endl; 
			cin >> newPantalla; 
			
			response = LG.Insertar(newPantalla); 
			cout << response << endl; 
			break; 
		case 2: 
			cout << "2.EXTRAER/ELIMINAR PANTALLA" << endl; 
			response = LG.Extraer(); 
			cout << "PANTALLA " << response << " ELIMINADA DE LA LISTA" << endl; 
			break; 
		case 3: 
			cout << "3.CONSULTAR ULTIMA PANTALLA REGISTRADA" << endl; 
			LG.Consultar(); 
			break; 
		case 4: 
			cout << "MOSTRAR LISTA DE PANTALLAS" << endl; 
			LG.Mostrar(); 
			break; 
		case 5: 
			cout << "HASTA LUEGO" << endl;
			break; 
		default: 
			cout << "Seleccione una opcion valida: " << endl; 
			
		}
		
		
	} while (selec != 5);

}