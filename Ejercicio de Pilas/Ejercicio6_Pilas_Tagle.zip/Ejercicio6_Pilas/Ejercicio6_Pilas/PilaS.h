#pragma once
#include <iostream>
#define TAM 9
using namespace std; 

class PilaS
{
		public:
		PilaS();
		string Insertar(string);
		string Extraer();
		void Mostrar();
		void Consultar();
	private:
		int min, max, tope;
		string* pila;
		string extra, topes; 


};

