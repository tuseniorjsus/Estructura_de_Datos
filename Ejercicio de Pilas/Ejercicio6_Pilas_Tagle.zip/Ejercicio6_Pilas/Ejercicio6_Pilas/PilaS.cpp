#include "PilaS.h"
PilaS::PilaS()
{
	min = 0;
	max = TAM;
	tope = min - 1;
	pila = new string[TAM];
	for (int i = 0; i < TAM; i++)
	{
		*(pila + i) = "";
	}
}




 string PilaS::Extraer()
 {
	 
	 if (tope < min)
	 {
		 return "Pila vac�a";
	 }
	 extra = pila[tope];
	 pila[tope] = "";
	 tope--;
	 
	 return extra;

 }
 string PilaS::Insertar(string insert)
 {
	 if (tope >= max)
		 return "Pila Llena";
	 tope++;
	 *(pila + tope) = insert;
	 return "Elemento Agregado a la Pila";
 }





 void PilaS::Mostrar()
 {
	 cout << "\nPILA: " << endl;
	 for (int i = tope; i >= 0; i--)
	 {
		 cout << "\t" << pila[i];
		 if (i == min)cout << "\t<= M�nimo";
		 if (i == tope)cout << "\t<= Tope";
		 if (i == max)cout << "\t<= M�ximo";
		 cout << endl;

	 }
	 cout << endl;
 }
 void PilaS::Consultar()
 {
	 if (tope < min)
	 {
		 cout<<"Pila vac�a"<<endl;
	 }
	 
	 string valor; 
	 if (tope>=min)
	 {
		 cout << "ULTIMA PANTALLA REGISTRADA: " << endl;
		 cout << *(pila + tope)<<endl;
	 }

 }


