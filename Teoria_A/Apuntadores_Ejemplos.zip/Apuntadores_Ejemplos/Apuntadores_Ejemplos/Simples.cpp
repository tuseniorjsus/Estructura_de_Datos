#include <iostream>
using namespace std;

int Mmain()
{
	int var1;

	int* ap_var1;

	cout << "Dime un valor entero: ";
	cin >> var1;

	ap_var1 = &var1;

	///* Primera opci�n: sin apuntadores */

	//cout << endl << "== Primera Opcion ==" << endl;
	//cout << "\t El nombre de la variable es: var1" << endl;
	//cout << "\t El valor de la variable es: " << var1 << endl;
	//cout << "\t La direccion de la variable es: " << &var1
	//	<< endl << endl << endl;




	/* Segunda opci�n: empleando apuntadores */

	cout << endl << "== Segunda Opcion ==" << endl;
	cout << "\t El nombre de la variable es: var1" << endl;
	cout << "\t El valor de la variable es: " << *ap_var1 << endl;
	cout << "\t La direccion de la variable es: " << ap_var1
		<< endl << endl << endl;



	return 0;
}