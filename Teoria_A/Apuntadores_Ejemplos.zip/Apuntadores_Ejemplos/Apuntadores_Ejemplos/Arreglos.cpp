#include <iostream>
using namespace std;

int MMmain()
{

	///***  Arreglo de enteros manejado como apuntador a entero ***/

	//int lista[6] = { 10, 20, 30 };

	//cout << "lista: " << lista << endl;  //direc.del primer elemento de lista

	//cout << " lista + 0: " << (lista + 0) << endl;

	//cout << " lista + 1: " << (lista + 1) << endl;

	//cout << " lista + 4: " << (lista + 4) << endl; //direc.del quinto elemento de lista

	//cout << "lista[0]  o  *lista: " << *lista << endl; //valor del primer elemento

	//cout << "lista[5]  o  *lista + 5: " << *(lista + 5) << endl;




	/***  Apuntador a un arreglo de enteros  ***/

	int lista[] = { 10, 20, 30 };

	int* plista = new int[3];  // (*plista) [  ] es un apuntador a un arreglo

	plista = lista;

	cout << "plista: " << plista << endl;  //direc.del primer elemento de lista

	cout << "plista + 0: " << (plista + 0) << endl;

	cout << "plista + 1: " << (plista + 1) << endl;

	cout << "plista + 2: " << (plista + 2) << endl; //direc.del tercer elemento de lista

	cout << "*plista: " << *plista << endl; //valor del primer elemento

	cout << "*plista + 2: " << *(plista + 2) << endl;



	return 0;
}