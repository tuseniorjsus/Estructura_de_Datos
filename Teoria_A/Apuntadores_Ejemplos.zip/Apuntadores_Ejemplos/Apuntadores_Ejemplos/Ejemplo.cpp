#include <iostream>
using namespace std;

void main()
{
	/* ------------------------------------------- */
	/*  Asigna memoria din�micamente a un arreglo  */
	/* ------------------------------------------- */

	int* p;		// Declara apuntador a int

	p = new int[5];	// Asigna 5 localidades de memoria para int, apuntadas por p

	*(p + 0) = 1;	// Inicializa elemento por elemento, ya que no es posible
	*(p + 1) = 3;	//            hacerlo como con los arreglos est�ticos
	*(p + 2) = 5;
	*(p + 3) = 7;
	*(p + 4) = 9;

	cout << p << endl;
	for (int i = 0; i < 5; i++)	cout << *(p + i) << "\t";
	cout << endl;

	for (int i = 0; i < 5; i++)	cout << p[i] << "\t";
	cout << endl;

	delete p;		// Libera las 5 localidades de memoria apuntadas por p

	cout << p << endl;
	for (int i = 0; i < 5; i++)	cout << *(p + i) << "\t";	// ERROR, no existen 5 localidades contiguas asignadas a p
	cout << endl;

}