#pragma once
#include <iostream>
using namespace std; 
#define MAX 12; 
//Programar con C++ el algoritmo para generar e inicializar un conjunto de registros que almacenen los datos de los empleados de una f�brica.
//ra cada empleado se debe almacenar su nombre, sus a�os de antig�edad y la cantidad de piezas fabricadas en cada uno de los �ltimos tres meses.
// necesita que una vez inicializados los registros, los ordene en forma ascendente de acuerdo a la antig�edad, empleando el m�todo de la burbuja.
struct Empleados
{
	string nom; 
	int antique; 
	int pieces[3]; 

}; 
class Fabrica
{
public: 
	Fabrica(); 
	void DatosE(); 
	void Ordenar(); 
	void MostrarDatos(); 
	void AgregarE(); 
private: 
	Empleados BancoI[12],* ListE; 
	int numE = 2; 
};

