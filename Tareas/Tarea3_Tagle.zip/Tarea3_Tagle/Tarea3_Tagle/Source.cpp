#include "Fabrica.h"
void MainMenu()
{
	cout << "-------------Menu Principal---------" << endl;
	cout << "1.Mostrar Trabajadores" << endl;
	cout << "2. Agregar Trabajadores" << endl;
	cout << "3.Salir" << endl;
}
int main()
{
	int option; 
	Fabrica DrSimi; 
	DrSimi.DatosE();
	do {
		MainMenu();
		cout << "Selecciona una opci�n: " << endl;
		cin >> option;
		switch (option)
		{
		case 1:
			DrSimi.MostrarDatos();
			break; 

		case 2:
			DrSimi.AgregarE();
			break; 

		case 3:
			break;
		default:
			cout << "Ingrese una opcion valida" << endl;
		}
	} while (option != 3); 
	
}