#include "Fabrica.h"

Fabrica::Fabrica()
{
	ListE = BancoI;
}

void Fabrica::DatosE()
{

	(ListE + 0)->nom = "Maricarmen"; 
	(ListE + 0)->antique = 16; 
	(ListE + 0)->pieces[0] = 11; (ListE + 0)->pieces[1] = 8; (ListE + 0)->pieces[2] = 19;

	(ListE + 1)->nom = "Sebastian";
	(ListE + 1)->antique = 6;
	(ListE + 1)->pieces[0] = 34; (ListE + 1)->pieces[1] = 43; (ListE + 1)->pieces[2] = 9;
	 
	

}

void Fabrica::Ordenar()
{
	bool ordenado; 
	Empleados aux; 
	for(int i =0; i<numE-1; i++)
	{
		ordenado = false; 
		while (ordenado != true) {
			ordenado = true; 
			if ((ListE + i)->antique > (ListE + i + 1)->antique)
			{
				  aux.nom = (ListE + i)->nom;  aux.antique=(ListE + i)->antique ;
				  (ListE + i)->nom = (ListE + i + 1)->nom;  (ListE + i)->antique = (ListE + i + 1)->antique; 
				  (ListE + i + 1)->nom = aux.nom; (ListE + i + 1)->antique = aux.antique;
				for (int j = 0; j < 3; j++)
				{
					aux.pieces[j] = (ListE + i)->pieces[j];
					(ListE + i)->pieces[j] = (ListE + i + 1)->pieces[j];
					(ListE + i + 1)->pieces[j] = aux.pieces[j];

				}
				ordenado = false; 
			}
		}

	}
	
}

void Fabrica::MostrarDatos()
{
	Ordenar(); 
	cout << "Lista de Empleados Dr Simi: " << endl; 
	for (int i = 0; i < numE; i++)
	{
		cout << "NOMBRE_: " << (ListE + i)->nom << endl; 
		cout << "ANTIGUEDAD_:" << (ListE + i)->antique << endl; 
		cout << "Ventas de los ultimos meses: " << endl; 
		for (int j = 0; j < 3; j++)
		{
			cout << "Mes " << j + 1 << ": " << (ListE + i)->pieces[j] << endl; 
		}
	}
}

void Fabrica::AgregarE()
{
	
	cout << "MENU DE REGISTRO DE EMPLEADOS: " << endl; 
	if (numE == 12 )
	{
		cout << "El arreglo ya esta lleno..... regresando al menu principal" << endl; 

	}
	else {
		cout << "Ingresa el nombre del  empleado: " << endl;
		cin >> (ListE + numE)->nom;
		cout << "Ingresa la antiguedad del empleado: " << endl;
		cin >> (ListE + numE)->antique;
		for (int i = 0; i < 3; i++)
		{
			cout << "Ingresa el n�mero de piezas fabricadas en el mes " << i + 1 << endl;
			cin >> (ListE + numE)->pieces[i];
		}
		numE++;
		Ordenar();
	}
}