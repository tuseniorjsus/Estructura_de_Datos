#include "ArreBi.h"

int main()
{
	ArreBi holi; 
	holi.mostrar(); 
	holi.OrdenarARR(); 
}