#pragma once
#include <iostream>
#include <ctime>
#include<stdlib.h>
#include <string>
using namespace std; 
class ArreBi
{
	//mOSTRAR NOMBRE ORDENAR POBLAR val = new int*[renglon](creaer arreglos de apuntadores):..........for(int i = 0; i<reng; i++) *(val+i) = new int[col]
public: 
	ArreBi(); 
	void LlenarARR(); 
	void OrdenarARR(); 
	void CrearARREGLO(); 
	void nombre(); 
	void mostrar(); 


private: 
	string namef; 
	int numf = 1; 
	int numc= 1; 
	int** aenteros; 
	
	
	
	
	
};


