#include "ArreBi.h"


ArreBi::ArreBi()
{

	int num; 
	num = num = 1 + rand() % (50 - 1);
	cout << "Ingresa el nombre de tu Matriz: " << endl; 
	cin >> namef; 
	//inicializar arreglo con valores otorgados por el usuario 
	cout << "Ingrese el n�mero de filas de la matriz" << endl; 
	cin >> numf; 
	cout << "Ingrese el n�mero de columnas de la matriz" << endl; 
	cin >> numc; 
	srand(time(0));// asignaci�n de n�meros para llenar el arreglo
	// como inicializar un puntero en bidimensional; 
	
	aenteros = new int* [numf]; 
	
	
	for(int i = 0; i<numf;i++)//for que recorre las filas ya establecidas previamente
	{
		*(aenteros + i) = new int [numc]; 
	}

	for (int l = 0; l < numf; l++)
	{
		for (int o = 0; o < numc; o++)
		{
			*(*(aenteros + l) + o) = 1 + rand() % 90; 
		}
	}
	
}

void ArreBi::mostrar()
{
	cout << "Tu Matriz : " << namef<< endl; 
	for (int i = 0; i < numf; i++)
	{
		for (int j = 0; j < numc; j++)
		{
			cout << *(*(aenteros + i) + j) << "\t";
		}
		cout << endl; 
	}
}
void ArreBi::OrdenarARR()
{
	bool isordenado ; 
	int aux = 0, it; 
	
	for (int i = 0; i < numf; i++)
	{
		isordenado = false;
		it = 0; 
		while (isordenado != true)
		{
			isordenado = true;
			for (int j = 0; j < numc-1-it; j++)
			{
				
				if (*(*(aenteros + i) + j) > *(*(aenteros + i) + j + 1))
				{
					aux = *(*(aenteros + i) + j);
					*(*(aenteros + i) + j) = *(*(aenteros + i) + j + 1);
					*(*(aenteros + i) + j + 1) = aux;
					isordenado = false;
				}
			}
			it++; 
		}
	}
	cout << "Ordenado : " << endl; 
	mostrar(); 
}
